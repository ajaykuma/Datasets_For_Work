package com.training.karaf.hello;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.startlevel.BundleStartLevel;
import org.osgi.framework.startlevel.FrameworkStartLevel;

public class Activator implements BundleActivator {

    @Override
    public void start(BundleContext ctx) {
        Bundle self = ctx.getBundle();
        int frameworkLevel = ctx.getBundle(0).adapt(FrameworkStartLevel.class).getStartLevel();
        int bundleLevel = self.adapt(BundleStartLevel.class).getStartLevel();
        System.out.println("""
                [hello] STARTED id=%d name=%s version=%s
                [hello] framework vendor=%s, start level (framework=%d, bundle=%d)
                [hello] running on Java %d""".formatted(
                self.getBundleId(), self.getSymbolicName(), self.getVersion(),
                ctx.getProperty(Constants.FRAMEWORK_VENDOR), frameworkLevel, bundleLevel,
                Runtime.version().feature()));
    }

    @Override
    public void stop(BundleContext ctx) {
        System.out.println("[hello] STOPPED id=" + ctx.getBundle().getBundleId());
    }
}
