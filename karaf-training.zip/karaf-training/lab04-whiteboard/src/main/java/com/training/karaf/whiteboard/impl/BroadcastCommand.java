package com.training.karaf.whiteboard.impl;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;

import com.training.karaf.whiteboard.api.GreetingListener;

@Component(service = Object.class, property = {
        "osgi.command.scope=training",
        "osgi.command.function=broadcast"
})
public class BroadcastCommand {

    private final List<GreetingListener> listeners = new CopyOnWriteArrayList<>();

    @Reference(cardinality = ReferenceCardinality.MULTIPLE,
               policy = ReferencePolicy.DYNAMIC,
               unbind = "removeListener")
    void addListener(GreetingListener listener) {
        listeners.add(listener);
    }

    void removeListener(GreetingListener listener) {
        listeners.remove(listener);
    }

    /** Usage: training:broadcast "good morning" */
    public String broadcast(String message) {
        int delivered = 0;
        for (GreetingListener l : listeners) {
            try {                      // one faulty listener must not stop the others
                l.onMessage(message);
                delivered++;
            } catch (RuntimeException e) {
                System.err.println("listener failed: " + e);
            }
        }
        return "delivered to " + delivered + " of " + listeners.size() + " listener(s)";
    }
}
