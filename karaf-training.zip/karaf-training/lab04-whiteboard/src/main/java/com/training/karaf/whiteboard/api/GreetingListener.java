package com.training.karaf.whiteboard.api;

@FunctionalInterface
public interface GreetingListener {
    void onMessage(String message);
}
