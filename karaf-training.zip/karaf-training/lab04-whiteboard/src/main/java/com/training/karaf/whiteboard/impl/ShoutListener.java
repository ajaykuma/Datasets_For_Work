package com.training.karaf.whiteboard.impl;

import org.osgi.service.component.annotations.Component;

import com.training.karaf.whiteboard.api.GreetingListener;

@Component(service = GreetingListener.class)
public class ShoutListener implements GreetingListener {
    @Override
    public void onMessage(String message) {
        System.out.println("[shout] " + message.toUpperCase());
    }
}
