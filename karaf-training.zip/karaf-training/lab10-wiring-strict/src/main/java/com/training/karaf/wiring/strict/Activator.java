package com.training.karaf.wiring.strict;

import java.util.Hashtable;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import com.training.karaf.wiring.lib.Message;

public class Activator implements BundleActivator {
    @Override
    public void start(BundleContext ctx) {
        Hashtable<String, Object> p = new Hashtable<>();
        p.put("osgi.command.scope", "training");
        p.put("osgi.command.function", new String[] { "strict" });
        ctx.registerService(Object.class, new Cmd(), p);
    }
    @Override
    public void stop(BundleContext ctx) { }

    public static class Cmd {
        public String strict() {
            try { return Message.text(); }
            catch (Throwable t) { return "FAILED at runtime: " + t; }
        }
    }
}