package com.training.karaf.greeter.impl;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(service = Object.class, property = {
        "osgi.command.scope=training",
        "osgi.command.function=greet"
})
public class GreetCommand {

    private final GreeterRegistry registry;

    @Activate
    public GreetCommand(@Reference GreeterRegistry registry) {
        this.registry = registry;
    }

    /** Usage: training:greet de Anna */
    public String greet(String language, String name) {
        return switch (registry.greet(language, name)) {
            case Greeting.Ok ok -> ok.text();
            case Greeting.Unsupported u ->
                    "No greeter for '" + u.language() + "'. Available: " + registry.languages();
        };
    }
}
