package com.training.karaf.greeter.impl;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.osgi.service.component.annotations.ReferencePolicy;

import com.training.karaf.greeter.api.Greeter;

@Component(service = GreeterRegistry.class)
public class GreeterRegistry {

    private final Map<String, Greeter> greeters = new ConcurrentHashMap<>();

    @Reference(service = Greeter.class,
               cardinality = ReferenceCardinality.MULTIPLE,
               policy = ReferencePolicy.DYNAMIC,
               unbind = "removeGreeter")
    void addGreeter(Greeter greeter, Map<String, Object> props) {
        greeters.put(String.valueOf(props.get("language")), greeter);
    }

    void removeGreeter(Greeter greeter, Map<String, Object> props) {
        greeters.remove(String.valueOf(props.get("language")), greeter);
    }

    public Greeting greet(String language, String name) {
        Greeter greeter = greeters.get(language);
        return greeter == null
                ? new Greeting.Unsupported(language)
                : new Greeting.Ok(language, greeter.greet(name));
    }

    public Set<String> languages() {
        return new TreeSet<>(greeters.keySet());
    }
}
