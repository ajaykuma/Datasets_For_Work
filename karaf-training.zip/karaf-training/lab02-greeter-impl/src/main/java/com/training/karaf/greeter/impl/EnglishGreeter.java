package com.training.karaf.greeter.impl;

import com.training.karaf.greeter.api.Greeter;
import org.osgi.service.component.annotations.Component;

@Component(service = Greeter.class, property = "language=en")
public class EnglishGreeter implements Greeter {
    @Override
    public String greet(String name) {
        return "Hello, " + name + "!";
    }
}
