package com.training.karaf.greeter.impl;

public sealed interface Greeting {
    record Ok(String language, String text) implements Greeting { }
    record Unsupported(String language) implements Greeting { }
}
