package com.training.karaf.greeter.api;

/** A service that greets a person in one language. */
public interface Greeter {
    String greet(String name);
}
