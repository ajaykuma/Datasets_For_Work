package com.training.karaf.dup.producer;

import java.util.Hashtable;
import java.util.function.Supplier;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import com.training.karaf.dup.api.Token;

public class Activator implements BundleActivator {
    @Override
    public void start(BundleContext ctx) {
        Supplier<Object> supplier = () -> new Token("made by producer");
        Hashtable<String, Object> p = new Hashtable<>();
        p.put("name", "dup-token");
        ctx.registerService(Supplier.class.getName(), supplier, p);
    }
    @Override
    public void stop(BundleContext ctx) { }
}