package com.training.karaf.jpa;

import java.util.List;

public interface BookService {
    Book add(String title, String author);
    List<Book> list();
}
