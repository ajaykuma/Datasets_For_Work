package com.training.karaf.jpa;

import java.util.List;

public class BookCommands {
    private BookService service;

    public void setService(BookService service) { this.service = service; }

    public Book addbook(String title, String author) { return service.add(title, author); }

    public List<Book> books() { return service.list(); }
}
