package com.training.karaf.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

public class BookServiceImpl implements BookService {

    @PersistenceContext(unitName = "training-pu")
    private EntityManager em;                // injected by Aries JPA

    @Override
    @Transactional(TxType.REQUIRED)
    public Book add(String title, String author) {
        Book book = new Book(title, author);
        em.persist(book);
        return book;
    }

    @Override
    @Transactional(TxType.SUPPORTS)
    public List<Book> list() {
        return em.createQuery("select b from Book b order by b.id", Book.class).getResultList();
    }
}
