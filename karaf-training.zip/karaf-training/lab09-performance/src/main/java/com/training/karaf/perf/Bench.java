package com.training.karaf.perf;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Plain-Java logic behind the Lab 9 commands (no OSGi types, so it is unit-testable). */
public final class Bench {

    private Bench() { }

    /** CPU-light work: sum of squares, so the JIT cannot remove it. */
    static long work(int n) {
        long s = 0;
        for (int i = 0; i < n; i++) {
            s += (long) i * i;
        }
        return s;
    }

    /** Runs 'tasks' CPU tasks on a fixed pool of 'threads' threads; returns elapsed ms. */
    public static String cpu(int threads, int tasks) throws Exception {
        long start = System.nanoTime();
        long sink = 0;
        try (ExecutorService pool = Executors.newFixedThreadPool(threads)) {
            List<Future<Long>> fs = new ArrayList<>();
            for (int i = 0; i < tasks; i++) {
                fs.add(pool.submit(() -> work(1_000)));
            }
            for (Future<Long> f : fs) {
                sink += f.get();
            }
        }
        long ms = (System.nanoTime() - start) / 1_000_000;
        return "cpu: threads=%d tasks=%d time=%d ms (checksum %d)".formatted(threads, tasks, ms, sink);
    }

    private static long blocking(ExecutorService pool, int tasks, long sleepMs) throws Exception {
        long start = System.nanoTime();
        List<Callable<Integer>> jobs = new ArrayList<>();
        for (int i = 0; i < tasks; i++) {
            jobs.add(() -> { Thread.sleep(sleepMs); return 1; });
        }
        for (Future<Integer> f : pool.invokeAll(jobs)) {
            f.get();
        }
        return (System.nanoTime() - start) / 1_000_000;
    }

    /** Runs 'tasks' blocking tasks (each sleeps 50 ms) on a fixed pool of 16 and on virtual threads. */
    public static String blocking(int tasks) throws Exception {
        long fixed;
        try (ExecutorService pool = Executors.newFixedThreadPool(16)) {
            fixed = blocking(pool, tasks, 50);
        }
        long virtual;
        try (ExecutorService pool = Executors.newVirtualThreadPerTaskExecutor()) {
            virtual = blocking(pool, tasks, 50);
        }
        return "blocking: tasks=%d (50 ms each) fixed-16=%d ms virtual=%d ms".formatted(tasks, fixed, virtual);
    }
}
