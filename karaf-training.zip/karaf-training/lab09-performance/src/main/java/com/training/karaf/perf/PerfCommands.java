package com.training.karaf.perf;

import org.osgi.service.component.annotations.Component;

@Component(service = Object.class, property = {
        "osgi.command.scope=training",
        "osgi.command.function=bench",
        "osgi.command.function=blocking"
})
public class PerfCommands {

    /** Usage: training:bench 8 200000 (threads, tasks) */
    public String bench(int threads, int tasks) throws Exception {
        return Bench.cpu(threads, tasks);
    }

    /** Usage: training:blocking 2000 (number of tasks that each sleep 50 ms) */
    public String blocking(int tasks) throws Exception {
        return Bench.blocking(tasks);
    }
}
