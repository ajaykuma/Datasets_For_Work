package com.training.karaf.resource.host;

import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator {

    @Override
    public void start(BundleContext ctx) {
        ClassLoader loader = Activator.class.getClassLoader();   // host loader, includes fragments
        for (Locale locale : List.of(Locale.ENGLISH, Locale.GERMAN)) {
            ResourceBundle bundle = ResourceBundle.getBundle("messages", locale, loader);
            System.out.println("[host] " + locale + " -> " + bundle.getString("greeting"));
        }
    }

    @Override
    public void stop(BundleContext ctx) { }
}
