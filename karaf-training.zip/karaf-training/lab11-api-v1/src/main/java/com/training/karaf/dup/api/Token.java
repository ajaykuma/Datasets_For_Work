package com.training.karaf.dup.api;

public class Token {
    private final String label;
    public Token(String label) { this.label = label; }
    public String label() { return label; }
}