# Karaf Training Project

Multi-module Maven project for the *Building OSGi Applications with Apache Karaf* training.
Java 21, Apache Karaf 4.4.9, Apache Felix 7.0.5, Maven 3.9+, Eclipse 2023-12+.

## Build

    mvn clean install

Every `labNN-*` module becomes a bundle (or, for `lab07-testing`, a test module). Karaf and Felix load
them from `target/*.jar` or, after `mvn install`, from your local Maven repository.

## Import into Eclipse

*File > Import > Maven > Existing Maven Projects*, choose this folder, select all modules.
Set the JRE to JDK 21 (Window > Preferences > Java > Installed JREs).
If Eclipse shows "Plugin execution not covered by lifecycle configuration: maven-bundle-plugin",
mark it as ignored. Tests: right-click `lab07-testing` > Run As > JUnit Test.

## Modules

| Module | Lab | Runs in |
|---|---|---|
| lab01-hello-bundle | 1 Bundle life cycle | Felix, Karaf |
| lab02-greeter-api, lab02-greeter-impl | 2 Services and Declarative Services | Karaf (needs `scr`) |
| lab03-compendium | 3 Config Admin, Metatype, Event Admin | Karaf |
| lab04-whiteboard, lab04-extender | 4 Whiteboard and Extender | Karaf (extender also Felix) |
| lab05-resource-host, lab05-resource-fragment-de | 5 Host and fragment | Felix, Karaf |
| lab06-jpa-book | 6 Aries JPA / JTA | Karaf only |
| lab07-testing | 7 Unit and embedded-framework tests | Eclipse, Maven |
| lab09-performance | 9 Measure CPU and blocking work (virtual threads) | Karaf |
| training-features.xml | 8 Provisioning and deployment | Karaf |

## Run the labs in Karaf (Windows paths shown; use your own folder)

    karaf> feature:install scr

    # Lab 1
    karaf> bundle:install -s file:/D:/karaf-training/lab01-hello-bundle/target/lab01-hello-bundle-1.0.0-SNAPSHOT.jar

    # Lab 2 (API first)
    karaf> bundle:install -s file:/D:/karaf-training/lab02-greeter-api/target/lab02-greeter-api-1.0.0-SNAPSHOT.jar
    karaf> bundle:install -s file:/D:/karaf-training/lab02-greeter-impl/target/lab02-greeter-impl-1.0.0-SNAPSHOT.jar
    karaf> training:greet de Anna

    # Lab 3 (eventadmin is already started in Karaf 4.4.9)
    karaf> bundle:install -s file:/D:/karaf-training/lab03-compendium/target/lab03-compendium-1.0.0-SNAPSHOT.jar
    karaf> training:greet cfg Alexander-Hamilton-Junior
    karaf> config:edit com.training.karaf.compendium.ConfigurableGreeter
    karaf> config:property-set prefix Howdy
    karaf> config:update

    # Lab 4
    karaf> bundle:install -s file:/D:/karaf-training/lab04-whiteboard/target/lab04-whiteboard-1.0.0-SNAPSHOT.jar
    karaf> bundle:install -s file:/D:/karaf-training/lab04-extender/target/lab04-extender-1.0.0-SNAPSHOT.jar
    karaf> training:broadcast "good morning"

    # Lab 5
    karaf> bundle:install -s file:/D:/karaf-training/lab05-resource-host/target/lab05-resource-host-1.0.0-SNAPSHOT.jar
    karaf> bundle:install file:/D:/karaf-training/lab05-resource-fragment-de/target/lab05-resource-fragment-de-1.0.0-SNAPSHOT.jar
    karaf> bundle:refresh <host-id>

    # Lab 9
    karaf> bundle:install -s file:/D:/karaf-training/lab09-performance/target/lab09-performance-1.0.0-SNAPSHOT.jar
    karaf> training:bench 8 200000        # threads, tasks
    karaf> training:blocking 2000

## Lab 6 (JPA) and Lab 8 (features)

    karaf> feature:repo-add file:/D:/karaf-training/training-features.xml
    karaf> feature:install -v training-app          # labs 2, 3, 4, 5 and 9
    karaf> feature:install -v training-jpa          # lab 6; dry-run the feature names first
    karaf> training:addbook "Dune" "Frank Herbert"
    karaf> training:books
    karaf> feature:uninstall training-app

The `mvn:` URLs inside the feature file need the bundles in your local Maven repository, so run
`mvn clean install` first. If Karaf cannot see `~/.m2/repository`, set
`org.ops4j.pax.url.mvn.localRepository` in `etc/org.ops4j.pax.url.mvn.cfg`.

## Windows tips

- Run `chcp 65001` before `bin\karaf.bat` to display the console table characters correctly.
- Use forward slashes in `file:/D:/...` URLs.
- Enable the SSH user by uncommenting `karaf = karaf,_g_:admingroup` in `etc/users.properties`.

## Status

The author could not compile or run this project in the authoring environment. Run `mvn clean install` and
dry-run every lab on your Karaf and JDK before teaching. Lab 6 depends on feature names from the Karaf
repositories (`feature:list | grep -E "jpa|hibernate|transaction|pax-jdbc"`).
