package com.training.karaf.dup.consumer;

import java.util.Hashtable;
import java.util.Collection;
import java.util.function.Supplier;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import com.training.karaf.dup.api.Token;

public class Activator implements BundleActivator {
    private BundleContext ctx;

    @Override
    public void start(BundleContext ctx) {
        this.ctx = ctx;
        Hashtable<String, Object> p = new Hashtable<>();
        p.put("osgi.command.scope", "training");
        p.put("osgi.command.function", new String[] { "consume" });
        ctx.registerService(Object.class, new Cmd(), p);
    }
    @Override
    public void stop(BundleContext ctx) { }

    public class Cmd {
        public String consume() throws Exception {
            Collection<ServiceReference<Supplier>> refs =
                ctx.getServiceReferences(Supplier.class, "(name=dup-token)");
            if (refs.isEmpty()) return "producer service not found";
            Object o = ctx.getService(refs.iterator().next()).get();
            try {
                Token t = (Token) o;
                return "OK: " + t.label();
            } catch (ClassCastException e) {
                return "ClassCastException: " + e.getMessage()
                    + "\n producer's Token loader: " + o.getClass().getClassLoader()
                    + "\n consumer's Token loader: " + Token.class.getClassLoader();
            }
        }
    }
}