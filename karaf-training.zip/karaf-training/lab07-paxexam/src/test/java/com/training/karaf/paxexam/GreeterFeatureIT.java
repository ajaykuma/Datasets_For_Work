
package com.training.karaf.paxexam;

import java.io.File;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.apache.karaf.features.Feature;
import org.apache.karaf.features.FeaturesService;

import org.ops4j.pax.exam.Configuration;
import org.ops4j.pax.exam.Option;
import org.ops4j.pax.exam.junit.PaxExam;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import static org.ops4j.pax.exam.CoreOptions.maven;
import static org.ops4j.pax.exam.CoreOptions.url;

import static org.ops4j.pax.exam.karaf.options.KarafDistributionOption.features;
import static org.ops4j.pax.exam.karaf.options.KarafDistributionOption.karafDistributionConfiguration;

@RunWith(PaxExam.class)
public class GreeterFeatureIT {

    @Inject
    private FeaturesService featuresService;

    @Configuration
    public Option[] config() {

        String featureRepository =
            new File("../training-features.xml")
                .getAbsoluteFile()
                .toURI()
                .toString();

        return new Option[] {

            karafDistributionConfiguration()
                .frameworkUrl(
                    maven()
                        .groupId("org.apache.karaf")
                        .artifactId("apache-karaf")
                        .version("4.4.9")
                        .type("tar.gz")
                )
                .useDeployFolder(false),

            features(
                url(featureRepository),
                "training-greeter"
            )
        };
    }

    @Test
    public void trainingGreeterFeatureIsInstalled() throws Exception {

        assertNotNull("Karaf FeaturesService was not injected",
                      featuresService);

        Feature feature =
            featuresService.getFeature("training-greeter", "1.0.0");

        assertNotNull("training-greeter feature was not found", feature);

        assertTrue(
            "training-greeter feature was not installed",
            featuresService.isInstalled(feature)
        );
    }
}

