package com.training.karaf.greeter.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.training.karaf.greeter.api.Greeter;

class GreeterRegistryTest {

    @Test
    void routesByLanguage() {
        GreeterRegistry registry = new GreeterRegistry();
        registry.addGreeter(new EnglishGreeter(), Map.of("language", "en"));
        registry.addGreeter(new GermanGreeter(), Map.of("language", "de"));

        assertEquals(new Greeting.Ok("de", "Hallo, Anna!"), registry.greet("de", "Anna"));
        assertEquals(new Greeting.Unsupported("fr"), registry.greet("fr", "Anna"));
        assertEquals(Set.of("de", "en"), registry.languages());
    }

    @Test
    void servicesCanDisappear() {
        GreeterRegistry registry = new GreeterRegistry();
        Greeter en = new EnglishGreeter();
        registry.addGreeter(en, Map.of("language", "en"));
        registry.removeGreeter(en, Map.of("language", "en"));
        assertTrue(registry.languages().isEmpty());
    }

    @Test
    void commandFormatsResults() {
        GreeterRegistry registry = new GreeterRegistry();
        registry.addGreeter(new GermanGreeter(), Map.of("language", "de"));
        GreetCommand command = new GreetCommand(registry);

        assertEquals("Hallo, Ada!", command.greet("de", "Ada"));
        assertTrue(command.greet("xx", "Ada").contains("Available: [de]"));
    }
}
