package com.training.karaf.testing;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class PingerActivator implements BundleActivator {

    private ServiceRegistration<Runnable> registration;

    @Override
    public void start(BundleContext ctx) {
        registration = ctx.registerService(Runnable.class, () -> System.out.println("pong"), null);
    }

    @Override
    public void stop(BundleContext ctx) {
        registration.unregister();
    }
}
