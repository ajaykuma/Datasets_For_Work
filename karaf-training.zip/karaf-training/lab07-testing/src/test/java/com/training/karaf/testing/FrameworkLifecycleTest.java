package com.training.karaf.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.launch.Framework;
import org.osgi.framework.launch.FrameworkFactory;

class FrameworkLifecycleTest {

    private Framework framework;

    @BeforeEach
    void startFramework(@TempDir Path storage) throws Exception {
        FrameworkFactory factory = ServiceLoader.load(FrameworkFactory.class).findFirst().orElseThrow();
        framework = factory.newFramework(Map.of(
                Constants.FRAMEWORK_STORAGE, storage.toString(),
                Constants.FRAMEWORK_STORAGE_CLEAN, Constants.FRAMEWORK_STORAGE_CLEAN_ONFIRSTINIT));
        framework.start();
    }

    @AfterEach
    void stopFramework() throws Exception {
        framework.stop();
        framework.waitForStop(10_000);
    }

    @Test
    void bundleMovesThroughItsLifecycle() throws Exception {
        BundleContext ctx = framework.getBundleContext();

        Bundle bundle = ctx.installBundle("test:pinger", pingerJar());
        assertEquals(Bundle.INSTALLED, bundle.getState());
        assertNull(ctx.getServiceReference(Runnable.class));

        bundle.start();
        assertEquals(Bundle.ACTIVE, bundle.getState());
        assertNotNull(ctx.getServiceReference(Runnable.class), "service registered by activator");

        bundle.stop();
        assertEquals(Bundle.RESOLVED, bundle.getState());
        assertNull(ctx.getServiceReference(Runnable.class), "service removed on stop");

        bundle.uninstall();
        assertEquals(Bundle.UNINSTALLED, bundle.getState());
    }

    /** Builds a minimal OSGi bundle JAR in memory from the test classpath. */
    private static InputStream pingerJar() throws IOException {
        Manifest manifest = new Manifest();
        Attributes attrs = manifest.getMainAttributes();
        attrs.put(Attributes.Name.MANIFEST_VERSION, "1.0");
        attrs.putValue("Bundle-ManifestVersion", "2");
        attrs.putValue("Bundle-SymbolicName", "test.pinger");
        attrs.putValue("Bundle-Version", "1.0.0");
        attrs.putValue("Bundle-Activator", PingerActivator.class.getName());
        attrs.putValue("Import-Package", "org.osgi.framework");

        String path = PingerActivator.class.getName().replace('.', '/') + ".class";
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (JarOutputStream jar = new JarOutputStream(bytes, manifest);
             InputStream clazz = PingerActivator.class.getClassLoader().getResourceAsStream(path)) {
            jar.putNextEntry(new JarEntry(path));
            clazz.transferTo(jar);
            jar.closeEntry();
        }
        return new ByteArrayInputStream(bytes.toByteArray());
    }
}
