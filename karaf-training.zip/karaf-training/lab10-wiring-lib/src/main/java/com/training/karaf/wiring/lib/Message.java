package com.training.karaf.wiring.lib;

public class Message {
    public static String text() { return "hello from lab10-wiring-lib"; }
}