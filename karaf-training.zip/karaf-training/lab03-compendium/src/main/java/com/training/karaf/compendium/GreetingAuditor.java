package com.training.karaf.compendium;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(property = EventConstants.EVENT_TOPIC + "=training/greeter/*")
public class GreetingAuditor implements EventHandler {

    private static final Logger LOG = LoggerFactory.getLogger(GreetingAuditor.class);

    @Override
    public void handleEvent(Event event) {
        LOG.info("audit: {} -> {}", event.getTopic(), event.getProperty("text"));
    }
}
