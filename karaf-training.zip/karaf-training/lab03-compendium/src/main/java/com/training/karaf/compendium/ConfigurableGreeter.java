package com.training.karaf.compendium;

import java.util.Map;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventAdmin;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import com.training.karaf.greeter.api.Greeter;

@Component(service = Greeter.class,
           property = "language=cfg",
           configurationPid = "com.training.karaf.compendium.ConfigurableGreeter")
@Designate(ocd = ConfigurableGreeter.Config.class)
public class ConfigurableGreeter implements Greeter {

    @ObjectClassDefinition(name = "Configurable Greeter",
                           description = "Settings for the 'cfg' greeter")
    public @interface Config {
        @AttributeDefinition(description = "Greeting prefix")
        String prefix() default "Greetings";

        @AttributeDefinition(description = "Names longer than this are shortened")
        int maxNameLength() default 12;
    }

    private final EventAdmin eventAdmin;
    private volatile Config config;

    @Activate
    public ConfigurableGreeter(@Reference EventAdmin eventAdmin, Config config) {
        this.eventAdmin = eventAdmin;
        this.config = config;
    }

    @Modified
    void modified(Config config) {   // called when the configuration changes; no restart
        this.config = config;
    }

    @Override
    public String greet(String name) {
        Config c = config;
        String shown = name.length() > c.maxNameLength()
                ? name.substring(0, c.maxNameLength()) + "..."
                : name;
        String text = c.prefix() + ", " + shown + "!";
        eventAdmin.postEvent(new Event("training/greeter/GREETED", Map.of("text", text)));
        return text;
    }
}
