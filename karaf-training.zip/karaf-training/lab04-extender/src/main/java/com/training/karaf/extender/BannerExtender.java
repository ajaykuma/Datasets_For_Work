package com.training.karaf.extender;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleEvent;
import org.osgi.util.tracker.BundleTracker;

public class BannerExtender implements BundleActivator {

    private BundleTracker<String> tracker;

    @Override
    public void start(BundleContext ctx) {
        tracker = new BundleTracker<String>(ctx, Bundle.ACTIVE, null) {
            @Override
            public String addingBundle(Bundle bundle, BundleEvent event) {
                String banner = bundle.getHeaders().get("X-Training-Banner");
                if (banner == null) {
                    return null;          // not interested: do not track
                }
                System.out.println("[extender] " + bundle.getSymbolicName() + ": " + banner);
                return banner;
            }

            @Override
            public void removedBundle(Bundle bundle, BundleEvent event, String banner) {
                System.out.println("[extender] bundle left: " + bundle.getSymbolicName());
            }
        };
        tracker.open();                   // also reports bundles that are already ACTIVE
    }

    @Override
    public void stop(BundleContext ctx) {
        tracker.close();
    }
}
